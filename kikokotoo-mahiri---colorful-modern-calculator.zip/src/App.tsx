/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { History, Palette, Settings, Sparkles, Maximize2, Minimize2 } from 'lucide-react';
import { THEMES } from './utils/themes';
import { AngleMode, CalculatorMode, HistoryItem, SoundEffectType, ThemeColors } from './types/calculator';
import { CalculationStep, evaluateExpression, evaluateScientificUnary, sanitizeNumber } from './utils/calculatorEngine';
import { playKeySound, playSuccessChime, triggerHaptic } from './utils/sound';
import { Display } from './components/Display';
import { Keypad } from './components/Keypad';
import { ScientificKeypad } from './components/ScientificKeypad';
import { HistoryTape } from './components/HistoryTape';
import { UnitConverter } from './components/UnitConverter';
import { ThemeSelectorModal } from './components/ThemeSelectorModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  // Calculator Core State
  const [displayValue, setDisplayValue] = useState<string>('0');
  const [expression, setExpression] = useState<string>('');
  const [isNewNumber, setIsNewNumber] = useState<boolean>(true);
  const [activeOperator, setActiveOperator] = useState<string | null>(null);
  const [memoryValue, setMemoryValue] = useState<number | null>(() => {
    try {
      const saved = localStorage.getItem('kikokotoo_memory');
      return saved ? parseFloat(saved) : null;
    } catch {
      return null;
    }
  });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Calculation steps tracking for long calculations
  const [calculationSteps, setCalculationSteps] = useState<CalculationStep[]>([]);
  const [showStepsTape, setShowStepsTape] = useState<boolean>(true);
  const [isWideWorkspace, setIsWideWorkspace] = useState<boolean>(false);

  // App Settings & Modes
  const [mode, setMode] = useState<CalculatorMode>('standard');
  const [angleMode, setAngleMode] = useState<AngleMode>('deg');
  const [theme, setTheme] = useState<ThemeColors>(() => {
    try {
      const savedId = localStorage.getItem('kikokotoo_theme');
      return THEMES.find((t) => t.id === savedId) || THEMES[0];
    } catch {
      return THEMES[0];
    }
  });
  const [soundType, setSoundType] = useState<SoundEffectType>('soft');
  const [hapticEnabled, setHapticEnabled] = useState<boolean>(true);

  // Modals & Panels
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isThemeModalOpen, setIsThemeModalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Calculation History
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('kikokotoo_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.map((item: HistoryItem) => ({
          ...item,
          timestamp: new Date(item.timestamp),
        }));
      }
    } catch {
      // Ignore
    }
    return [];
  });

  // Save memory & history to localStorage
  useEffect(() => {
    try {
      if (memoryValue !== null) {
        localStorage.setItem('kikokotoo_memory', memoryValue.toString());
      } else {
        localStorage.removeItem('kikokotoo_memory');
      }
    } catch {
      // Ignore
    }
  }, [memoryValue]);

  useEffect(() => {
    try {
      localStorage.setItem('kikokotoo_history', JSON.stringify(history.slice(0, 50)));
    } catch {
      // Ignore
    }
  }, [history]);

  useEffect(() => {
    try {
      localStorage.setItem('kikokotoo_theme', theme.id);
    } catch {
      // Ignore
    }
  }, [theme]);

  // Tactile sound & haptics trigger
  const triggerFeedback = useCallback(
    (tone: 'num' | 'op' | 'eq' | 'clear' = 'num') => {
      playKeySound(soundType, tone);
      if (hapticEnabled) {
        triggerHaptic(tone === 'eq' ? 'medium' : 'light');
      }
    },
    [soundType, hapticEnabled]
  );

  // Number input handler
  const handleNumber = useCallback(
    (digit: string) => {
      triggerFeedback('num');
      setErrorMsg(null);

      if (digit === '.') {
        if (isNewNumber) {
          setDisplayValue('0.');
          setIsNewNumber(false);
          return;
        }
        if (!displayValue.includes('.')) {
          setDisplayValue((prev) => prev + '.');
          setIsNewNumber(false);
        }
        return;
      }

      if (isNewNumber || displayValue === '0' || displayValue === 'Error') {
        setDisplayValue(digit);
        setIsNewNumber(false);
      } else {
        if (displayValue.replace(/[^0-9]/g, '').length < 18) {
          setDisplayValue((prev) => prev + digit);
        }
      }
    },
    [displayValue, isNewNumber, triggerFeedback]
  );

  // Operator input handler (+, -, ×, ÷)
  const handleOperator = useCallback(
    (op: string) => {
      triggerFeedback('op');
      setErrorMsg(null);

      // If user presses operator consecutively, change active operator
      if (activeOperator && isNewNumber) {
        setActiveOperator(op);
        setExpression((prev) => prev.slice(0, -2) + `${op} `);
        return;
      }

      // If there's an existing expression and the user is typing, evaluate intermediate step
      if (expression && !isNewNumber) {
        const fullExpr = `${expression}${displayValue}`;
        const evalRes = evaluateExpression(fullExpr);
        if (evalRes.success) {
          // Record step in calculation breakdown
          const stepItem: CalculationStep = {
            id: Date.now().toString() + Math.random(),
            stepNumber: calculationSteps.length + 1,
            operation: `${activeOperator || '+'} ${displayValue}`,
            operatorSymbol: op,
            inputNumber: displayValue,
            runningTotal: evalRes.result,
          };
          setCalculationSteps((prev) => [...prev, stepItem]);

          setDisplayValue(evalRes.result);
          setExpression(`${evalRes.result} ${op} `);
        } else {
          setExpression(`${displayValue} ${op} `);
        }
      } else {
        // Initial first number added
        const stepItem: CalculationStep = {
          id: Date.now().toString() + Math.random(),
          stepNumber: 1,
          operation: `Kuanzia ${displayValue}`,
          operatorSymbol: op,
          inputNumber: displayValue,
          runningTotal: displayValue,
        };
        setCalculationSteps([stepItem]);
        setExpression(`${displayValue} ${op} `);
      }

      setActiveOperator(op);
      setIsNewNumber(true);
    },
    [activeOperator, isNewNumber, expression, displayValue, calculationSteps, triggerFeedback]
  );

  // Equals (=) handler
  const handleEquals = useCallback(() => {
    triggerFeedback('eq');
    if (!expression && !activeOperator) return;

    const fullExpr = expression ? `${expression}${displayValue}` : displayValue;
    const evalRes = evaluateExpression(fullExpr);

    if (evalRes.success) {
      playSuccessChime();

      // Add final step to calculation steps list
      if (expression) {
        const finalStepItem: CalculationStep = {
          id: Date.now().toString() + Math.random(),
          stepNumber: calculationSteps.length + 1,
          operation: `${activeOperator || '+'} ${displayValue} =`,
          operatorSymbol: '=',
          inputNumber: displayValue,
          runningTotal: evalRes.result,
        };
        setCalculationSteps((prev) => [...prev, finalStepItem]);
      }

      setDisplayValue(evalRes.result);
      setExpression('');
      setActiveOperator(null);
      setIsNewNumber(true);
      setErrorMsg(null);

      // Add to permanent history
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        expression: fullExpr,
        result: evalRes.result,
        timestamp: new Date(),
      };
      setHistory((prev) => [newHistoryItem, ...prev]);
    } else {
      setErrorMsg(evalRes.errorMsg || 'Kosa la hesabu');
      setDisplayValue('Error');
      setIsNewNumber(true);
    }
  }, [expression, activeOperator, displayValue, calculationSteps, triggerFeedback]);

  // Clear (AC) handler
  const handleClear = useCallback(() => {
    triggerFeedback('clear');
    setDisplayValue('0');
    setExpression('');
    setActiveOperator(null);
    setCalculationSteps([]);
    setIsNewNumber(true);
    setErrorMsg(null);
  }, [triggerFeedback]);

  // Backspace handler
  const handleBackspace = useCallback(() => {
    triggerFeedback('num');
    if (isNewNumber || displayValue === 'Error') {
      setDisplayValue('0');
      return;
    }
    if (displayValue.length > 1) {
      setDisplayValue((prev) => prev.slice(0, -1));
    } else {
      setDisplayValue('0');
      setIsNewNumber(true);
    }
  }, [isNewNumber, displayValue, triggerFeedback]);

  // Toggle positive / negative sign
  const handleToggleSign = useCallback(() => {
    triggerFeedback('num');
    if (displayValue === '0' || displayValue === 'Error') return;
    if (displayValue.startsWith('-')) {
      setDisplayValue(displayValue.substring(1));
    } else {
      setDisplayValue('-' + displayValue);
    }
  }, [displayValue, triggerFeedback]);

  // Percentage handler (%)
  const handlePercentage = useCallback(() => {
    triggerFeedback('op');
    const num = parseFloat(displayValue);
    if (!isNaN(num)) {
      const res = sanitizeNumber(num / 100);
      setDisplayValue(res.toString());
      setIsNewNumber(true);
    }
  }, [displayValue, triggerFeedback]);

  // Scientific unary function handler (sin, cos, log, etc.)
  const handleScientificFunc = useCallback(
    (funcName: string) => {
      triggerFeedback('op');
      const num = parseFloat(displayValue);
      if (isNaN(num)) return;

      const evalRes = evaluateScientificUnary(funcName, num, angleMode);
      if (evalRes.success) {
        const resStr = evalRes.result.toString();
        const newHistoryItem: HistoryItem = {
          id: Date.now().toString(),
          expression: `${funcName}(${displayValue})`,
          result: resStr,
          timestamp: new Date(),
        };
        setHistory((prev) => [newHistoryItem, ...prev]);

        // Add to steps list
        const sciStep: CalculationStep = {
          id: Date.now().toString() + Math.random(),
          stepNumber: calculationSteps.length + 1,
          operation: `${funcName}(${displayValue})`,
          operatorSymbol: funcName,
          inputNumber: displayValue,
          runningTotal: resStr,
        };
        setCalculationSteps((prev) => [...prev, sciStep]);

        setDisplayValue(resStr);
        setIsNewNumber(true);
        setErrorMsg(null);
      } else {
        setErrorMsg(evalRes.errorMsg || 'Kosa la kisayansi');
        setDisplayValue('Error');
        setIsNewNumber(true);
      }
    },
    [displayValue, angleMode, calculationSteps, triggerFeedback]
  );

  // Append token for scientific expressions (e.g. '(', ')', 'π', 'e', '^')
  const handleAppendToken = useCallback(
    (token: string) => {
      triggerFeedback('op');
      if (token === 'π') {
        setDisplayValue(Math.PI.toString());
        setIsNewNumber(true);
        return;
      }
      if (token === 'e') {
        setDisplayValue(Math.E.toString());
        setIsNewNumber(true);
        return;
      }

      if (token === '(') {
        setExpression((prev) => `${prev}( `);
        setIsNewNumber(true);
        return;
      }

      if (token === ')') {
        setExpression((prev) => `${prev}${displayValue} ) `);
        setIsNewNumber(true);
        return;
      }

      if (token === '^') {
        setExpression(`${displayValue} ^ `);
        setActiveOperator('^');
        setIsNewNumber(true);
        return;
      }
    },
    [displayValue, triggerFeedback]
  );

  // Memory Actions
  const handleMemoryAction = useCallback(
    (action: 'MC' | 'MR' | 'M+' | 'M-' | 'MS') => {
      triggerFeedback('op');
      const currentNum = parseFloat(displayValue) || 0;

      switch (action) {
        case 'MC':
          setMemoryValue(null);
          break;
        case 'MR':
          if (memoryValue !== null) {
            setDisplayValue(memoryValue.toString());
            setIsNewNumber(true);
          }
          break;
        case 'M+':
          setMemoryValue((prev) => sanitizeNumber((prev || 0) + currentNum));
          setIsNewNumber(true);
          break;
        case 'M-':
          setMemoryValue((prev) => sanitizeNumber((prev || 0) - currentNum));
          setIsNewNumber(true);
          break;
        case 'MS':
          setMemoryValue(currentNum);
          setIsNewNumber(true);
          break;
      }
    },
    [displayValue, memoryValue, triggerFeedback]
  );

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement instanceof HTMLInputElement ||
        document.activeElement instanceof HTMLSelectElement
      ) {
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        handleNumber(e.key);
      } else if (e.key === '.') {
        handleNumber('.');
      } else if (e.key === '+') {
        handleOperator('+');
      } else if (e.key === '-') {
        handleOperator('-');
      } else if (e.key === '*' || e.key === 'x' || e.key === 'X') {
        handleOperator('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape') {
        handleClear();
      } else if (e.key === '%') {
        handlePercentage();
      } else if (e.key === '(' || e.key === ')') {
        handleAppendToken(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    handleNumber,
    handleOperator,
    handleEquals,
    handleBackspace,
    handleClear,
    handlePercentage,
    handleAppendToken,
  ]);

  // Determine calculator layout container width
  const containerWidthClass = isWideWorkspace
    ? 'max-w-4xl'
    : mode === 'scientific'
    ? 'max-w-2xl'
    : 'max-w-lg';

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-500 flex flex-col justify-between ${theme.pageBackground} text-slate-100 selection:bg-amber-400 selection:text-slate-950 relative overflow-hidden`}
    >
      {/* Ambient background glow orbs */}
      <div
        className={`absolute -top-32 -left-32 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-40 transition-all duration-700 ${theme.glowColor}`}
      />
      <div
        className={`absolute -bottom-32 -right-32 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-40 transition-all duration-700 ${theme.glowColor}`}
      />

      {/* Top Header Bar */}
      <header className="w-full border-b border-white/10 backdrop-blur-md sticky top-0 z-40 px-3 md:px-8 py-3 flex items-center justify-between">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-2">
          <span className="text-base md:text-xl font-black tracking-tight bg-gradient-to-r from-white via-slate-100 to-amber-200 bg-clip-text text-transparent">
            Kikokotoo Mahiri
          </span>
        </div>

        {/* Zone 2: Navigation Mode Tabs */}
        <nav className="flex items-center gap-1 p-1 bg-white/5 rounded-xl border border-white/10">
          <button
            onClick={() => setMode('standard')}
            className={`px-2.5 md:px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              mode === 'standard'
                ? 'bg-white/15 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Kawaida
          </button>
          <button
            onClick={() => setMode('scientific')}
            className={`px-2.5 md:px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              mode === 'scientific'
                ? 'bg-white/15 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Kisayansi
          </button>
          <button
            onClick={() => setMode('converter')}
            className={`px-2.5 md:px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              mode === 'converter'
                ? 'bg-white/15 text-white shadow-sm font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Vizio
          </button>
        </nav>

        {/* Zone 3: Actions (Wide workspace toggle, Themes, History, Settings) */}
        <div className="flex items-center gap-1.5 md:gap-2">
          {/* Toggle Wide Workspace Size */}
          <button
            onClick={() => setIsWideWorkspace(!isWideWorkspace)}
            className={`p-2 rounded-xl text-xs font-medium transition-all border cursor-pointer hidden sm:flex items-center gap-1.5 ${
              isWideWorkspace
                ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold shadow-md'
                : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
            }`}
            title={isWideWorkspace ? 'Punguza ukubwa (Compact view)' : 'Ongeza ukubwa uwe mpana (Wide view)'}
          >
            {isWideWorkspace ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            <span className="hidden md:inline">{isWideWorkspace ? 'Ukubwa wa Kawaida' : 'Uwanja Mpana'}</span>
          </button>

          {/* Theme Palette Switcher */}
          <button
            onClick={() => setIsThemeModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-all border border-white/10 cursor-pointer"
            title="Badili Rangi za Kuvutia"
          >
            <Palette className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden lg:inline">{theme.nameSw}</span>
          </button>

          {/* History Button */}
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all border border-white/10 relative cursor-pointer"
            title="Historia ya Mahesabu"
            aria-label="Historia ya Mahesabu"
          >
            <History className="w-4 h-4" />
            {history.length > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900" />
            )}
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all border border-white/10 cursor-pointer"
            title="Mipangilio"
            aria-label="Mipangilio"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col items-center justify-center p-2.5 sm:p-5 md:p-8 w-full max-w-7xl mx-auto z-10">
        <div
          className={`w-full transition-all duration-300 rounded-3xl p-4 sm:p-6 md:p-8 border ${containerWidthClass} ${theme.calculatorBody} ${theme.calculatorBorder}`}
        >
          {mode !== 'converter' ? (
            <div className="flex flex-col gap-4 md:gap-5">
              {/* Screen Display with Expanded Breakdown Tape */}
              <Display
                expression={expression}
                displayValue={displayValue}
                memoryValue={memoryValue}
                angleMode={angleMode}
                mode={mode}
                theme={theme}
                errorMsg={errorMsg}
                calculationSteps={calculationSteps}
                showStepsTape={showStepsTape}
                onToggleStepsTape={() => setShowStepsTape(!showStepsTape)}
                onClear={handleClear}
                onBackspace={handleBackspace}
                onToggleAngleMode={() =>
                  setAngleMode((prev) => (prev === 'deg' ? 'rad' : 'deg'))
                }
                onSelectStepNumber={(numVal) => {
                  setDisplayValue(numVal);
                  setIsNewNumber(true);
                }}
              />

              {/* Scientific Keypad (if in scientific mode) */}
              {mode === 'scientific' && (
                <ScientificKeypad
                  theme={theme}
                  angleMode={angleMode}
                  onScientificFunc={handleScientificFunc}
                  onAppendToken={handleAppendToken}
                  onToggleAngleMode={() =>
                    setAngleMode((prev) => (prev === 'deg' ? 'rad' : 'deg'))
                  }
                />
              )}

              {/* Standard Keypad & Numbers */}
              <Keypad
                theme={theme}
                activeOperator={activeOperator}
                onNumber={handleNumber}
                onOperator={handleOperator}
                onEquals={handleEquals}
                onClear={handleClear}
                onBackspace={handleBackspace}
                onToggleSign={handleToggleSign}
                onPercentage={handlePercentage}
                onMemoryAction={handleMemoryAction}
                hasMemory={memoryValue !== null}
              />
            </div>
          ) : (
            <UnitConverter theme={theme} />
          )}
        </div>

        {/* Quick Tips / Keyboard info footer helper */}
        <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-slate-400 mt-4 select-none px-4">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Namba zote zilizoongezwa zimepangwa kwenye mkanda wa juu
          </span>
          <span aria-hidden="true" className="hidden sm:inline">·</span>
          <span>Njia ya {mode === 'standard' ? 'Kawaida' : mode === 'scientific' ? 'Kisayansi' : 'Vizio'}</span>
          {isWideWorkspace && (
            <>
              <span aria-hidden="true" className="hidden sm:inline">·</span>
              <span className="text-amber-300 font-medium">Uwanja Mpana Umeamilishwa</span>
            </>
          )}
        </div>
      </main>

      {/* Quiet Footer */}
      <footer className="w-full py-3 px-6 text-center text-xs text-slate-500 border-t border-white/5">
        <span>Kikokotoo Mahiri &copy; {new Date().getFullYear()} · Rangi za Kuvutia na Mahesabu ya Haraka</span>
      </footer>

      {/* Modals & Drawers */}
      <HistoryTape
        history={history}
        theme={theme}
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onClearHistory={() => setHistory([])}
        onSelectResult={(res) => {
          setDisplayValue(res);
          setIsNewNumber(true);
        }}
        onSelectExpression={(expr) => {
          setExpression(expr + ' ');
          setIsNewNumber(true);
        }}
      />

      <ThemeSelectorModal
        isOpen={isThemeModalOpen}
        onClose={() => setIsThemeModalOpen(false)}
        activeThemeId={theme.id}
        onSelectTheme={(newTheme) => setTheme(newTheme)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        soundType={soundType}
        onSelectSound={(st) => setSoundType(st)}
        hapticEnabled={hapticEnabled}
        onToggleHaptic={() => setHapticEnabled(!hapticEnabled)}
      />
    </div>
  );
}
