import { AngleMode } from '../types/calculator';

/**
 * An item in the step-by-step calculation breakdown tape
 */
export interface CalculationStep {
  id: string;
  stepNumber: number;
  operation: string; // e.g. "Mwanzo", "+ 4,500", "× 12"
  operatorSymbol?: string;
  inputNumber: string;
  runningTotal: string;
}

/**
 * Format raw number string or calculation result with commas for visual clarity
 */
export function formatDisplayValue(val: string): string {
  if (!val || val === 'Error' || val === 'NaN' || val === 'Infinity' || val === '-Infinity') {
    return val;
  }

  // Check if scientific notation
  if (val.includes('e') || val.includes('E')) {
    return val;
  }

  // Split into integer and decimal parts
  const parts = val.split('.');
  const intPart = parts[0];
  const decPart = parts.length > 1 ? parts[1] : null;

  // Add thousand separators to intPart while preserving negative sign
  const isNegative = intPart.startsWith('-');
  const absInt = isNegative ? intPart.slice(1) : intPart;
  const formattedInt = absInt.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  const result = (isNegative ? '-' : '') + formattedInt;
  return decPart !== null ? `${result}.${decPart}` : result;
}

/**
 * Clean floating point imprecision (e.g., 0.1 + 0.2 = 0.3)
 */
export function sanitizeNumber(num: number): number {
  if (!Number.isFinite(num)) return num;
  return parseFloat(num.toPrecision(12));
}

/**
 * Calculate factorial of an integer
 */
export function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) return NaN;
  if (n === 0 || n === 1) return 1;
  if (n > 170) return Infinity; // JS Number overflow limit
  let res = 1;
  for (let i = 2; i <= n; i++) {
    res *= i;
  }
  return res;
}

/**
 * Evaluate single scientific functions on a value
 */
export function evaluateScientificUnary(
  funcName: string,
  value: number,
  angleMode: AngleMode
): { success: boolean; result: number; errorMsg?: string } {
  try {
    let res: number;
    const toRadians = angleMode === 'deg' ? (deg: number) => (deg * Math.PI) / 180 : (rad: number) => rad;
    const fromRadians = angleMode === 'deg' ? (rad: number) => (rad * 180) / Math.PI : (rad: number) => rad;

    switch (funcName) {
      case 'sin':
        res = Math.sin(toRadians(value));
        if (Math.abs(res) < 1e-15) res = 0;
        break;
      case 'cos':
        res = Math.cos(toRadians(value));
        if (Math.abs(res) < 1e-15) res = 0;
        break;
      case 'tan': {
        const rad = toRadians(value);
        if (Math.abs(Math.cos(rad)) < 1e-12) {
          return { success: false, result: NaN, errorMsg: 'Haijulikani (Tan 90°)' };
        }
        res = Math.tan(rad);
        break;
      }
      case 'asin': {
        if (value < -1 || value > 1) {
          return { success: false, result: NaN, errorMsg: 'Nje ya kipimo [-1, 1]' };
        }
        res = fromRadians(Math.asin(value));
        break;
      }
      case 'acos': {
        if (value < -1 || value > 1) {
          return { success: false, result: NaN, errorMsg: 'Nje ya kipimo [-1, 1]' };
        }
        res = fromRadians(Math.acos(value));
        break;
      }
      case 'atan':
        res = fromRadians(Math.atan(value));
        break;
      case 'sqrt': {
        if (value < 0) {
          return { success: false, result: NaN, errorMsg: 'Mzizi hasi hauhesabiki' };
        }
        res = Math.sqrt(value);
        break;
      }
      case 'cbrt':
        res = Math.cbrt(value);
        break;
      case 'sqr':
        res = value * value;
        break;
      case 'cube':
        res = value * value * value;
        break;
      case 'inv': {
        if (value === 0) {
          return { success: false, result: NaN, errorMsg: 'Haiwezekani kugawa kwa 0' };
        }
        res = 1 / value;
        break;
      }
      case 'log': {
        if (value <= 0) {
          return { success: false, result: NaN, errorMsg: 'Namba lazima iwe > 0' };
        }
        res = Math.log10(value);
        break;
      }
      case 'ln': {
        if (value <= 0) {
          return { success: false, result: NaN, errorMsg: 'Namba lazima iwe > 0' };
        }
        res = Math.log(value);
        break;
      }
      case 'fact': {
        if (value < 0 || !Number.isInteger(value)) {
          return { success: false, result: NaN, errorMsg: 'Namba lazima iwe kamili chanya' };
        }
        res = factorial(value);
        break;
      }
      case 'abs':
        res = Math.abs(value);
        break;
      case 'exp':
        res = Math.exp(value);
        break;
      case 'tenPow':
        res = Math.pow(10, value);
        break;
      default:
        return { success: false, result: NaN, errorMsg: 'Kazi haitambuliki' };
    }

    return { success: true, result: sanitizeNumber(res) };
  } catch {
    return { success: false, result: NaN, errorMsg: 'Kosa la kihesabu' };
  }
}

/**
 * Tokenize and safely evaluate arithmetic expression containing +, -, ×, ÷, ^, %
 */
export function evaluateExpression(expr: string): { success: boolean; result: string; errorMsg?: string } {
  try {
    if (!expr || expr.trim() === '') {
      return { success: true, result: '0' };
    }

    // Replace visual symbols with standard JS operators
    let sanitized = expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/π/g, `${Math.PI}`)
      .replace(/e/g, `${Math.E}`)
      .replace(/%/g, '/100');

    // Balance open parentheses if user didn't close them
    const openParenCount = (sanitized.match(/\(/g) || []).length;
    const closeParenCount = (sanitized.match(/\)/g) || []).length;
    if (openParenCount > closeParenCount) {
      sanitized += ')'.repeat(openParenCount - closeParenCount);
    }

    // Power operator replacement
    sanitized = sanitized.replace(/\^/g, '**');

    // Safety check - strictly allow only digits, operators, math constants, parentheses, and spaces
    if (!/^[\d\s+\-*/().%*^]+$/.test(sanitized)) {
      return { success: false, result: 'Error', errorMsg: 'Kielezi si sahihi' };
    }

    // Division by zero check
    if (/\/\s*0(?![.\d])/.test(sanitized)) {
      return { success: false, result: 'Error', errorMsg: 'Haiwezekani kugawa kwa sifuri' };
    }

    // Safe mathematical function evaluation using Function constructor with no global scope leakage
    // eslint-disable-next-line @typescript-eslint/no-implied-eval
    const evalFn = new Function(`"use strict"; return (${sanitized});`);
    const num = evalFn();

    if (num === Infinity || num === -Infinity) {
      return { success: false, result: 'Error', errorMsg: 'Hesabu imezidi upeo (Infinity)' };
    }

    if (isNaN(num)) {
      return { success: false, result: 'Error', errorMsg: 'Si namba halisi (NaN)' };
    }

    const sanitizedNum = sanitizeNumber(num);
    return { success: true, result: sanitizedNum.toString() };
  } catch {
    return { success: false, result: 'Error', errorMsg: 'Muundo usio sahihi wa mahesabu' };
  }
}
