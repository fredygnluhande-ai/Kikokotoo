import React from 'react';
import { motion } from 'motion/react';

export type KeyVariant = 'number' | 'operator' | 'function' | 'equals' | 'memory' | 'scientific';

interface KeyButtonProps {
  label: React.ReactNode;
  value: string;
  onClick: (val: string) => void;
  variant?: KeyVariant;
  className?: string;
  subLabel?: string;
  isActive?: boolean;
  disabled?: boolean;
  'aria-label'?: string;
}

export const KeyButton: React.FC<KeyButtonProps> = ({
  label,
  value,
  onClick,
  variant = 'number',
  className = '',
  subLabel,
  isActive = false,
  disabled = false,
  'aria-label': ariaLabel,
}) => {
  return (
    <motion.button
      type="button"
      whileTap={{ scale: disabled ? 1 : 0.94 }}
      transition={{ type: 'spring', stiffness: 450, damping: 25 }}
      onClick={() => !disabled && onClick(value)}
      disabled={disabled}
      aria-label={ariaLabel || (typeof label === 'string' ? label : value)}
      className={`
        relative select-none flex flex-col items-center justify-center rounded-xl md:rounded-2xl
        transition-all duration-150 font-medium cursor-pointer border
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/40
        disabled:opacity-40 disabled:cursor-not-allowed
        ${isActive ? 'ring-2 ring-white/60 brightness-110' : ''}
        ${className}
      `}
    >
      <span className="leading-none text-center flex items-center justify-center">
        {label}
      </span>
      {subLabel && (
        <span className="text-[10px] opacity-60 font-normal mt-0.5 leading-none">
          {subLabel}
        </span>
      )}
    </motion.button>
  );
};
