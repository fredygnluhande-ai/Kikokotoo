import React from 'react';
import { Delete } from 'lucide-react';
import { KeyButton } from './KeyButton';
import { ThemeColors } from '../types/calculator';

interface KeypadProps {
  theme: ThemeColors;
  activeOperator: string | null;
  onNumber: (digit: string) => void;
  onOperator: (op: string) => void;
  onEquals: () => void;
  onClear: () => void;
  onBackspace: () => void;
  onToggleSign: () => void;
  onPercentage: () => void;
  onMemoryAction: (action: 'MC' | 'MR' | 'M+' | 'M-' | 'MS') => void;
  hasMemory: boolean;
}

export const Keypad: React.FC<KeypadProps> = ({
  theme,
  activeOperator,
  onNumber,
  onOperator,
  onEquals,
  onClear,
  onBackspace,
  onToggleSign,
  onPercentage,
  onMemoryAction,
  hasMemory,
}) => {
  return (
    <div className="flex flex-col gap-2.5 md:gap-3 w-full">
      {/* Memory Controls Bar */}
      <div className="grid grid-cols-5 gap-1.5 md:gap-2 px-0.5">
        <KeyButton
          label="MC"
          value="MC"
          onClick={() => onMemoryAction('MC')}
          disabled={!hasMemory}
          variant="memory"
          className="h-8 md:h-9 text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border-transparent"
          aria-label="Futa Kumbukumbu (Memory Clear)"
        />
        <KeyButton
          label="MR"
          value="MR"
          onClick={() => onMemoryAction('MR')}
          disabled={!hasMemory}
          variant="memory"
          className="h-8 md:h-9 text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border-transparent"
          aria-label="Rudisha Kumbukumbu (Memory Recall)"
        />
        <KeyButton
          label="M+"
          value="M+"
          onClick={() => onMemoryAction('M+')}
          variant="memory"
          className="h-8 md:h-9 text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border-transparent"
          aria-label="Ongeza kwenye Kumbukumbu (Memory Add)"
        />
        <KeyButton
          label="M-"
          value="M-"
          onClick={() => onMemoryAction('M-')}
          variant="memory"
          className="h-8 md:h-9 text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border-transparent"
          aria-label="Punguza kwenye Kumbukumbu (Memory Subtract)"
        />
        <KeyButton
          label="MS"
          value="MS"
          onClick={() => onMemoryAction('MS')}
          variant="memory"
          className="h-8 md:h-9 text-xs text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border-transparent"
          aria-label="Hifadhi kwenye Kumbukumbu (Memory Store)"
        />
      </div>

      {/* Main Standard Grid */}
      <div className="grid grid-cols-4 gap-2 md:gap-3">
        {/* Row 1 */}
        <KeyButton
          label="AC"
          value="AC"
          onClick={onClear}
          variant="function"
          className={`h-14 md:h-16 text-lg md:text-xl font-bold ${theme.functionBtn.bg} ${theme.functionBtn.text} ${theme.functionBtn.hover} ${theme.functionBtn.border}`}
          aria-label="Futa Yote (All Clear)"
        />
        <KeyButton
          label="+/-"
          value="+/-"
          onClick={onToggleSign}
          variant="function"
          className={`h-14 md:h-16 text-lg md:text-xl font-semibold ${theme.functionBtn.bg} ${theme.functionBtn.text} ${theme.functionBtn.hover} ${theme.functionBtn.border}`}
          aria-label="Badili Ishara Chanya au Hasi (Toggle Sign)"
        />
        <KeyButton
          label="%"
          value="%"
          onClick={onPercentage}
          variant="function"
          className={`h-14 md:h-16 text-lg md:text-xl font-semibold ${theme.functionBtn.bg} ${theme.functionBtn.text} ${theme.functionBtn.hover} ${theme.functionBtn.border}`}
          aria-label="Asilimia (Percentage)"
        />
        <KeyButton
          label="÷"
          value="÷"
          onClick={() => onOperator('÷')}
          isActive={activeOperator === '÷'}
          variant="operator"
          className={`h-14 md:h-16 text-2xl font-bold border-transparent ${theme.operatorBtn.bg} ${theme.operatorBtn.text} ${theme.operatorBtn.hover}`}
          aria-label="Gawa (Divide)"
        />

        {/* Row 2 */}
        <KeyButton
          label="7"
          value="7"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="8"
          value="8"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="9"
          value="9"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="×"
          value="×"
          onClick={() => onOperator('×')}
          isActive={activeOperator === '×'}
          variant="operator"
          className={`h-14 md:h-16 text-2xl font-bold border-transparent ${theme.operatorBtn.bg} ${theme.operatorBtn.text} ${theme.operatorBtn.hover}`}
          aria-label="Zidisha (Multiply)"
        />

        {/* Row 3 */}
        <KeyButton
          label="4"
          value="4"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="5"
          value="5"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="6"
          value="6"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="−"
          value="-"
          onClick={() => onOperator('-')}
          isActive={activeOperator === '-'}
          variant="operator"
          className={`h-14 md:h-16 text-2xl font-bold border-transparent ${theme.operatorBtn.bg} ${theme.operatorBtn.text} ${theme.operatorBtn.hover}`}
          aria-label="Toa (Subtract)"
        />

        {/* Row 4 */}
        <KeyButton
          label="1"
          value="1"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="2"
          value="2"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="3"
          value="3"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="+"
          value="+"
          onClick={() => onOperator('+')}
          isActive={activeOperator === '+'}
          variant="operator"
          className={`h-14 md:h-16 text-2xl font-bold border-transparent ${theme.operatorBtn.bg} ${theme.operatorBtn.text} ${theme.operatorBtn.hover}`}
          aria-label="Jumlisha (Add)"
        />

        {/* Row 5 */}
        <KeyButton
          label="0"
          value="0"
          onClick={onNumber}
          className={`h-14 md:h-16 text-xl md:text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
        />
        <KeyButton
          label="."
          value="."
          onClick={onNumber}
          className={`h-14 md:h-16 text-2xl font-bold ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
          aria-label="Nukta (Decimal point)"
        />
        <KeyButton
          label={<Delete className="w-5 h-5" />}
          value="backspace"
          onClick={onBackspace}
          className={`h-14 md:h-16 text-lg ${theme.numberBtn.bg} ${theme.numberBtn.text} ${theme.numberBtn.hover} ${theme.numberBtn.border}`}
          aria-label="Futa herufi (Backspace)"
        />
        <KeyButton
          label="="
          value="="
          onClick={onEquals}
          variant="equals"
          className={`h-14 md:h-16 text-2xl font-black border-transparent ${theme.equalsBtn.bg} ${theme.equalsBtn.text} ${theme.equalsBtn.hover} ${theme.equalsBtn.shadow}`}
          aria-label="Sawa na (Equals)"
        />
      </div>
    </div>
  );
};
