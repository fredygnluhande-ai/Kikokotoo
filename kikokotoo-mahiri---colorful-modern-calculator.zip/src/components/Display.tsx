import React, { useState, useRef, useEffect } from 'react';
import { Copy, Check, Delete, ListOrdered, ChevronDown, ChevronUp, Layers } from 'lucide-react';
import { AngleMode, CalculatorMode, ThemeColors } from '../types/calculator';
import { CalculationStep, formatDisplayValue } from '../utils/calculatorEngine';

interface DisplayProps {
  expression: string;
  displayValue: string;
  memoryValue: number | null;
  angleMode: AngleMode;
  mode: CalculatorMode;
  theme: ThemeColors;
  errorMsg: string | null;
  calculationSteps: CalculationStep[];
  showStepsTape: boolean;
  onToggleStepsTape: () => void;
  onClear: () => void;
  onBackspace: () => void;
  onToggleAngleMode: () => void;
  onSelectStepNumber?: (val: string) => void;
}

export const Display: React.FC<DisplayProps> = ({
  expression,
  displayValue,
  memoryValue,
  angleMode,
  mode,
  theme,
  errorMsg,
  calculationSteps,
  showStepsTape,
  onToggleStepsTape,
  onClear,
  onBackspace,
  onToggleAngleMode,
  onSelectStepNumber,
}) => {
  const [copied, setCopied] = useState(false);
  const stepsContainerRef = useRef<HTMLDivElement>(null);
  const exprContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll steps list to bottom as new numbers are added
  useEffect(() => {
    if (stepsContainerRef.current) {
      stepsContainerRef.current.scrollTop = stepsContainerRef.current.scrollHeight;
    }
  }, [calculationSteps, displayValue]);

  // Auto-scroll horizontal expression tape to end
  useEffect(() => {
    if (exprContainerRef.current) {
      exprContainerRef.current.scrollLeft = exprContainerRef.current.scrollWidth;
    }
  }, [expression, displayValue]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(displayValue);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  // Adjust font size dynamically based on length
  const formattedVal = formatDisplayValue(displayValue);
  const textLength = formattedVal.length;

  let fontSizeClass = 'text-4xl md:text-5xl';
  if (textLength > 18) {
    fontSizeClass = 'text-2xl md:text-3xl';
  } else if (textLength > 12) {
    fontSizeClass = 'text-3xl md:text-4xl';
  } else if (textLength > 8) {
    fontSizeClass = 'text-4xl md:text-4.5xl';
  }

  // Parse expression tokens for the ribbon
  const tokens = expression.trim().split(/\s+/).filter(Boolean);

  return (
    <div
      className={`relative w-full rounded-2xl md:rounded-3xl p-4 md:p-5 flex flex-col justify-between transition-all duration-300 border shadow-inner ${theme.displayBackground}`}
    >
      {/* Top Indicators & Controls Bar */}
      <div className="flex items-center justify-between text-xs font-medium mb-2 tracking-wider">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Scientific Mode Angle Toggle */}
          {mode === 'scientific' && (
            <button
              onClick={onToggleAngleMode}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold tracking-wider transition-colors border cursor-pointer ${
                angleMode === 'deg'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
              }`}
              title="Badili Digrii / Radiani (DEG / RAD)"
            >
              {angleMode.toUpperCase()}
            </button>
          )}

          {/* Memory Active Indicator */}
          {memoryValue !== null && (
            <span
              className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30"
              title={`Kumbukumbu (Memory): ${memoryValue}`}
            >
              M = {formatDisplayValue(memoryValue.toString())}
            </span>
          )}

          {/* Toggle Calculation Steps Tape (Uwanja wa Namba Zinazoongezwa) */}
          <button
            onClick={onToggleStepsTape}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all border cursor-pointer ${
              showStepsTape
                ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md font-bold'
                : 'bg-white/10 text-slate-300 border-white/10 hover:bg-white/15'
            }`}
            title="Onyesha / Ficha orodha ya namba za mahesabu marefu"
          >
            <ListOrdered className="w-3.5 h-3.5" />
            <span>Orodha ya Hatua</span>
            {calculationSteps.length > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${showStepsTape ? 'bg-slate-900 text-amber-300' : 'bg-amber-400/30 text-amber-200'}`}>
                {calculationSteps.length + (expression ? 1 : 0)}
              </span>
            )}
            {showStepsTape ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>

        {/* Action icons: Backspace & Copy */}
        <div className="flex items-center gap-1">
          <button
            onClick={onBackspace}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Futa herufi ya mwisho (Backspace)"
            aria-label="Futa herufi ya mwisho"
          >
            <Delete className="w-4 h-4" />
          </button>
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors relative cursor-pointer"
            title="Nakili jibu (Copy result)"
            aria-label="Nakili jibu"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            {copied && (
              <span className="absolute -top-7 right-0 text-[10px] bg-emerald-500 text-slate-950 font-bold px-2 py-0.5 rounded shadow-lg whitespace-nowrap z-20">
                Imenakiliwa!
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Expanded Step-by-Step Long Calculation Tape */}
      {showStepsTape && (
        <div className="mb-3 p-3 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-md">
          <div className="flex items-center justify-between text-[11px] text-slate-400 pb-1.5 mb-1.5 border-b border-white/10">
            <span className="flex items-center gap-1.5 font-medium">
              <Layers className="w-3 h-3 text-amber-400" />
              Mlolongo wa namba za mahesabu marefu:
            </span>
            <span className="text-[10px] text-slate-500">
              {calculationSteps.length} hatua zilizopita
            </span>
          </div>

          <div
            ref={stepsContainerRef}
            className="max-h-36 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar text-xs font-mono"
          >
            {calculationSteps.length === 0 && !expression ? (
              <div className="py-3 text-center text-slate-500 text-xs italic">
                Weka namba na alama za (+, -, ×, ÷) ili orodha ya mahesabu marefu ianze kupangwa hapa.
              </div>
            ) : (
              <>
                {calculationSteps.map((step) => (
                  <div
                    key={step.id}
                    onClick={() => onSelectStepNumber && onSelectStepNumber(step.runningTotal)}
                    className="flex items-center justify-between py-1 px-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 transition-colors cursor-pointer group"
                    title={`Bonyeza kutumia jumla hii (${step.runningTotal})`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-white/10 text-[10px] text-slate-400 flex items-center justify-center font-sans">
                        #{step.stepNumber}
                      </span>
                      <span className="text-slate-300 font-semibold">
                        {step.operation}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-500 group-hover:text-slate-400 text-[11px]">jumla:</span>
                      <span className="font-bold text-amber-300 group-hover:underline">
                        {formatDisplayValue(step.runningTotal)}
                      </span>
                    </div>
                  </div>
                ))}

                {/* Currently typing active step indicator */}
                {expression && (
                  <div className="flex items-center justify-between py-1 px-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 animate-pulse">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-amber-400/20 text-[10px] text-amber-300 flex items-center justify-center font-sans font-bold">
                        #{calculationSteps.length + 1}
                      </span>
                      <span className="font-semibold">
                        {tokens[tokens.length - 1] || ''} {formatDisplayValue(displayValue)}
                      </span>
                    </div>
                    <span className="text-[10px] uppercase font-sans tracking-wider opacity-80">
                      Inaongezwa...
                    </span>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* Horizontal Scrollable Expression Ribbon for Long Equations */}
      <div
        ref={exprContainerRef}
        className="min-h-7 overflow-x-auto text-right whitespace-nowrap custom-scrollbar flex items-center justify-end gap-1.5 py-1"
      >
        {tokens.length === 0 ? (
          <span className={`font-mono text-sm tracking-wide ${theme.displaySubTextColor}`}>
            0
          </span>
        ) : (
          tokens.map((token, idx) => {
            const isOperator = ['+', '-', '×', '÷', '^', '%'].includes(token);
            return (
              <span
                key={idx}
                className={`font-mono inline-block px-1.5 py-0.5 rounded text-sm transition-all ${
                  isOperator
                    ? 'font-bold text-amber-400 bg-white/5 border border-white/5'
                    : `${theme.displaySubTextColor}`
                }`}
              >
                {isOperator ? token : formatDisplayValue(token)}
              </span>
            );
          })
        )}
      </div>

      {/* Main Big Display Result */}
      <div className="flex items-baseline justify-end overflow-x-auto overflow-y-hidden custom-scrollbar py-2">
        <span
          className={`font-mono font-black tracking-tight select-all tabular-nums transition-all ${fontSizeClass} ${theme.displayTextColor}`}
        >
          {formattedVal}
        </span>
      </div>

      {/* Error message banner if calculation error occurred */}
      {errorMsg && (
        <div className="mt-2 px-3 py-1.5 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
          <span className="font-medium">{errorMsg}</span>
          <button
            onClick={onClear}
            className="text-[11px] underline hover:text-white font-bold ml-2 cursor-pointer"
          >
            Futa Yote (AC)
          </button>
        </div>
      )}
    </div>
  );
};
