import React, { useState } from 'react';
import { KeyButton } from './KeyButton';
import { AngleMode, ThemeColors } from '../types/calculator';

interface ScientificKeypadProps {
  theme: ThemeColors;
  angleMode: AngleMode;
  onScientificFunc: (funcName: string) => void;
  onAppendToken: (token: string) => void;
  onToggleAngleMode: () => void;
}

export const ScientificKeypad: React.FC<ScientificKeypadProps> = ({
  theme,
  angleMode,
  onScientificFunc,
  onAppendToken,
  onToggleAngleMode,
}) => {
  const [isSecondMode, setIsSecondMode] = useState(false);

  const sciBtnClass = `h-11 md:h-12 text-sm font-semibold border ${theme.functionBtn.bg} ${theme.functionBtn.text} ${theme.functionBtn.hover} ${theme.functionBtn.border}`;

  return (
    <div className="flex flex-col gap-2 w-full pt-1">
      {/* Top Scientific Toolbar */}
      <div className="flex items-center justify-between px-1 text-xs">
        <button
          onClick={() => setIsSecondMode(!isSecondMode)}
          className={`px-3 py-1 rounded-lg font-bold transition-all border ${
            isSecondMode
              ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md'
              : 'bg-white/10 text-slate-300 border-white/10 hover:bg-white/20'
          }`}
        >
          2nd {isSecondMode ? 'ON' : ''}
        </button>

        <button
          onClick={onToggleAngleMode}
          className={`px-3 py-1 rounded-lg font-bold transition-all border ${
            angleMode === 'deg'
              ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
              : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
          }`}
        >
          {angleMode === 'deg' ? 'Digrii (DEG)' : 'Radiani (RAD)'}
        </button>
      </div>

      {/* Grid of Scientific Functions */}
      <div className="grid grid-cols-4 md:grid-cols-5 gap-1.5 md:gap-2">
        {/* Row 1 */}
        <KeyButton
          label="("
          value="("
          onClick={() => onAppendToken('(')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label=")"
          value=")"
          onClick={() => onAppendToken(')')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label="π"
          value="π"
          onClick={() => onAppendToken('π')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label="e"
          value="e"
          onClick={() => onAppendToken('e')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label="x!"
          value="fact"
          onClick={() => onScientificFunc('fact')}
          variant="scientific"
          className={`${sciBtnClass} hidden md:flex`}
          subLabel="Factorial"
        />

        {/* Row 2: Trig */}
        <KeyButton
          label={isSecondMode ? 'sin⁻¹' : 'sin'}
          value={isSecondMode ? 'asin' : 'sin'}
          onClick={() => onScientificFunc(isSecondMode ? 'asin' : 'sin')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label={isSecondMode ? 'cos⁻¹' : 'cos'}
          value={isSecondMode ? 'acos' : 'cos'}
          onClick={() => onScientificFunc(isSecondMode ? 'acos' : 'cos')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label={isSecondMode ? 'tan⁻¹' : 'tan'}
          value={isSecondMode ? 'atan' : 'tan'}
          onClick={() => onScientificFunc(isSecondMode ? 'atan' : 'tan')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label="1/x"
          value="inv"
          onClick={() => onScientificFunc('inv')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label="|x|"
          value="abs"
          onClick={() => onScientificFunc('abs')}
          variant="scientific"
          className={`${sciBtnClass} hidden md:flex`}
          subLabel="Absolute"
        />

        {/* Row 3: Logarithms & Powers */}
        <KeyButton
          label={isSecondMode ? 'eˣ' : 'ln'}
          value={isSecondMode ? 'exp' : 'ln'}
          onClick={() => onScientificFunc(isSecondMode ? 'exp' : 'ln')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label={isSecondMode ? '10ˣ' : 'log'}
          value={isSecondMode ? 'tenPow' : 'log'}
          onClick={() => onScientificFunc(isSecondMode ? 'tenPow' : 'log')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label={isSecondMode ? '∛x' : '√x'}
          value={isSecondMode ? 'cbrt' : 'sqrt'}
          onClick={() => onScientificFunc(isSecondMode ? 'cbrt' : 'sqrt')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label={isSecondMode ? 'x³' : 'x²'}
          value={isSecondMode ? 'cube' : 'sqr'}
          onClick={() => onScientificFunc(isSecondMode ? 'cube' : 'sqr')}
          variant="scientific"
          className={sciBtnClass}
        />
        <KeyButton
          label="xʸ"
          value="^"
          onClick={() => onAppendToken('^')}
          variant="scientific"
          className={`${sciBtnClass} hidden md:flex`}
          subLabel="Power"
        />
      </div>
    </div>
  );
};
