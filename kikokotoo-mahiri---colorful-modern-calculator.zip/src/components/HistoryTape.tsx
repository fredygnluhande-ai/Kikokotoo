import React from 'react';
import { Trash2, Copy, ArrowUpLeft, X } from 'lucide-react';
import { HistoryItem, ThemeColors } from '../types/calculator';

interface HistoryTapeProps {
  history: HistoryItem[];
  theme: ThemeColors;
  isOpen: boolean;
  onClose: () => void;
  onClearHistory: () => void;
  onSelectResult: (val: string) => void;
  onSelectExpression: (val: string) => void;
}

export const HistoryTape: React.FC<HistoryTapeProps> = ({
  history,
  theme,
  isOpen,
  onClose,
  onClearHistory,
  onSelectResult,
  onSelectExpression,
}) => {
  if (!isOpen) return null;

  const handleCopyAll = async () => {
    if (history.length === 0) return;
    const text = history
      .map(
        (item) =>
          `${item.expression} = ${item.result} (${new Date(item.timestamp).toLocaleTimeString()})`
      )
      .join('\n');
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Ignore
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`w-full max-w-md max-h-[85vh] rounded-3xl p-5 md:p-6 flex flex-col border shadow-2xl ${theme.calculatorBody} ${theme.calculatorBorder}`}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight">
              Historia ya Mahesabu
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Bonyeza hesabu yoyote kuirejesha kwenye skrini
            </p>
          </div>

          <div className="flex items-center gap-1">
            {history.length > 0 && (
              <>
                <button
                  onClick={handleCopyAll}
                  className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                  title="Nakili historia yote"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={onClearHistory}
                  className="p-2 rounded-xl text-rose-400 hover:text-rose-300 hover:bg-rose-500/20 transition-colors"
                  title="Futa historia yote"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors ml-1"
              title="Funga"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5 custom-scrollbar min-h-[220px]">
          {history.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <span className="text-3xl mb-2">📜</span>
              <p className="text-sm font-medium">Bado hakuna historia ya mahesabu</p>
              <p className="text-xs text-slate-500 mt-1">
                Fanya mahesabu yoyote na yatatokea hapa moja kwa moja.
              </p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                className="group relative p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all text-right"
              >
                {/* Clean unboxed timestamp metadata */}
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span className="text-[11px] font-mono opacity-70">
                    {new Date(item.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </span>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => {
                        onSelectExpression(item.expression);
                        onClose();
                      }}
                      className="px-2 py-0.5 text-[10px] rounded bg-white/10 hover:bg-white/20 text-slate-200 flex items-center gap-1"
                      title="Tumia kielezi hiki"
                    >
                      <ArrowUpLeft className="w-3 h-3" />
                      Kielezi
                    </button>
                    <button
                      onClick={() => {
                        onSelectResult(item.result);
                        onClose();
                      }}
                      className="px-2 py-0.5 text-[10px] rounded bg-white/10 hover:bg-white/20 text-slate-200 flex items-center gap-1"
                      title="Tumia jibu hili"
                    >
                      <ArrowUpLeft className="w-3 h-3" />
                      Jibu
                    </button>
                  </div>
                </div>

                {/* Equation Expression */}
                <button
                  type="button"
                  onClick={() => {
                    onSelectExpression(item.expression);
                    onClose();
                  }}
                  className="block w-full text-right font-mono text-sm text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  {item.expression}
                </button>

                {/* Equals & Result */}
                <button
                  type="button"
                  onClick={() => {
                    onSelectResult(item.result);
                    onClose();
                  }}
                  className={`block w-full text-right font-mono text-xl font-bold tracking-tight mt-0.5 cursor-pointer hover:underline ${theme.accentColor}`}
                >
                  = {item.result}
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            Funga Dirisha
          </button>
        </div>
      </div>
    </div>
  );
};
