import React from 'react';
import { X, Check } from 'lucide-react';
import { THEMES } from '../utils/themes';
import { ThemeColors } from '../types/calculator';

interface ThemeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeThemeId: string;
  onSelectTheme: (theme: ThemeColors) => void;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  isOpen,
  onClose,
  activeThemeId,
  onSelectTheme,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl p-5 md:p-6 bg-slate-900 border border-white/10 shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <span>🎨</span> Rangi na Mandhari ya Kuvutia
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Chagua muonekano unaoupenda kwa ajili ya kikokotoo chako
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Theme Cards Grid */}
        <div className="flex-1 overflow-y-auto py-4 grid grid-cols-1 md:grid-cols-2 gap-3 custom-scrollbar">
          {THEMES.map((th) => {
            const isSelected = th.id === activeThemeId;
            return (
              <button
                key={th.id}
                onClick={() => {
                  onSelectTheme(th);
                  onClose();
                }}
                className={`relative p-3.5 rounded-2xl text-left border transition-all duration-200 group cursor-pointer ${
                  isSelected
                    ? 'border-amber-400/80 bg-white/10 ring-2 ring-amber-400/30 shadow-lg'
                    : 'border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                {/* Gradient banner */}
                <div
                  className={`h-10 w-full rounded-xl mb-3 bg-gradient-to-r ${th.previewGradient} flex items-center justify-end px-3 shadow-inner`}
                >
                  {isSelected && (
                    <span className="w-6 h-6 rounded-full bg-white text-slate-950 flex items-center justify-center shadow">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </span>
                  )}
                </div>

                <div className="flex items-baseline justify-between">
                  <span className="font-bold text-white text-sm tracking-tight">
                    {th.nameSw}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {th.nameEn}
                  </span>
                </div>

                <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {th.descriptionSw}
                </p>

                {/* Micro preview swatches */}
                <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-white/5">
                  <span className="text-[10px] text-slate-500 mr-1">Rangi:</span>
                  <span className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-amber-400 to-rose-500 border border-white/20" />
                  <span className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 border border-white/20" />
                  <span className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-fuchsia-400 to-purple-500 border border-white/20" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            Sawa
          </button>
        </div>
      </div>
    </div>
  );
};
