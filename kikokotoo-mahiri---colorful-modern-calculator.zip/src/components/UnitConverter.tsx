import React, { useState } from 'react';
import { ArrowLeftRight, Check, Copy } from 'lucide-react';
import { ThemeColors } from '../types/calculator';

interface UnitConverterProps {
  theme: ThemeColors;
}

type ConverterCategory = 'length' | 'weight' | 'temperature' | 'discount';

interface UnitDef {
  id: string;
  nameSw: string;
  symbol: string;
  toBase: (v: number) => number;
  fromBase: (v: number) => number;
}

const LENGTH_UNITS: UnitDef[] = [
  { id: 'm', nameSw: 'Mita', symbol: 'm', toBase: (v) => v, fromBase: (v) => v },
  { id: 'km', nameSw: 'Kilomita', symbol: 'km', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
  { id: 'cm', nameSw: 'Sentimita', symbol: 'cm', toBase: (v) => v / 100, fromBase: (v) => v * 100 },
  { id: 'mm', nameSw: 'Milimita', symbol: 'mm', toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
  { id: 'ft', nameSw: 'Futi (Feet)', symbol: 'ft', toBase: (v) => v * 0.3048, fromBase: (v) => v / 0.3048 },
  { id: 'in', nameSw: 'Inchi (Inch)', symbol: 'in', toBase: (v) => v * 0.0254, fromBase: (v) => v / 0.0254 },
  { id: 'mi', nameSw: 'Maili (Mile)', symbol: 'mi', toBase: (v) => v * 1609.344, fromBase: (v) => v / 1609.344 },
];

const WEIGHT_UNITS: UnitDef[] = [
  { id: 'kg', nameSw: 'Kilogramu', symbol: 'kg', toBase: (v) => v, fromBase: (v) => v },
  { id: 'g', nameSw: 'Gramu', symbol: 'g', toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
  { id: 'mg', nameSw: 'Miligramu', symbol: 'mg', toBase: (v) => v / 1000000, fromBase: (v) => v * 1000000 },
  { id: 'lb', nameSw: 'Ratili (Pound)', symbol: 'lb', toBase: (v) => v * 0.45359237, fromBase: (v) => v / 0.45359237 },
  { id: 'oz', nameSw: 'Wakia (Ounce)', symbol: 'oz', toBase: (v) => v * 0.0283495, fromBase: (v) => v / 0.0283495 },
  { id: 't', nameSw: 'Tani (Tonne)', symbol: 't', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
];

const TEMP_UNITS: UnitDef[] = [
  { id: 'c', nameSw: 'Selsiasi', symbol: '°C', toBase: (v) => v, fromBase: (v) => v },
  { id: 'f', nameSw: 'Farenhaiti', symbol: '°F', toBase: (v) => ((v - 32) * 5) / 9, fromBase: (v) => (v * 9) / 5 + 32 },
  { id: 'k', nameSw: 'Kelvini', symbol: 'K', toBase: (v) => v - 273.15, fromBase: (v) => v + 273.15 },
];

export const UnitConverter: React.FC<UnitConverterProps> = ({ theme }) => {
  const [category, setCategory] = useState<ConverterCategory>('length');
  const [inputValue, setInputValue] = useState<string>('1');
  const [fromUnitId, setFromUnitId] = useState<string>('m');
  const [toUnitId, setToUnitId] = useState<string>('cm');

  // Discount state
  const [originalPrice, setOriginalPrice] = useState<string>('10000');
  const [discountPercent, setDiscountPercent] = useState<string>('15');

  const [copied, setCopied] = useState(false);

  const getUnits = () => {
    switch (category) {
      case 'length':
        return LENGTH_UNITS;
      case 'weight':
        return WEIGHT_UNITS;
      case 'temperature':
        return TEMP_UNITS;
      default:
        return LENGTH_UNITS;
    }
  };

  const handleCategoryChange = (newCat: ConverterCategory) => {
    setCategory(newCat);
    if (newCat === 'length') {
      setFromUnitId('m');
      setToUnitId('cm');
    } else if (newCat === 'weight') {
      setFromUnitId('kg');
      setToUnitId('g');
    } else if (newCat === 'temperature') {
      setFromUnitId('c');
      setToUnitId('f');
    }
  };

  // Compute conversion
  const computeResult = (): string => {
    const num = parseFloat(inputValue);
    if (isNaN(num)) return '0';

    const units = getUnits();
    const fromUnit = units.find((u) => u.id === fromUnitId) || units[0];
    const toUnit = units.find((u) => u.id === toUnitId) || units[1];

    const baseVal = fromUnit.toBase(num);
    const resultVal = toUnit.fromBase(baseVal);

    if (Math.abs(resultVal) < 0.000001 && resultVal !== 0) {
      return resultVal.toExponential(4);
    }
    return parseFloat(resultVal.toFixed(6)).toString();
  };

  const swapUnits = () => {
    setFromUnitId(toUnitId);
    setToUnitId(fromUnitId);
  };

  const handleCopy = async (val: string) => {
    try {
      await navigator.clipboard.writeText(val);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  // Discount calculations
  const priceNum = parseFloat(originalPrice) || 0;
  const discNum = parseFloat(discountPercent) || 0;
  const savedAmount = (priceNum * discNum) / 100;
  const finalPrice = Math.max(0, priceNum - savedAmount);

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Category Segmented Control */}
      <div className="flex items-center gap-1 p-1 bg-white/5 rounded-xl border border-white/5 overflow-x-auto custom-scrollbar">
        <button
          onClick={() => handleCategoryChange('length')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 text-xs font-semibold rounded-lg transition-all ${
            category === 'length'
              ? `${theme.equalsBtn.bg} text-white shadow-md`
              : 'text-slate-300 hover:text-white hover:bg-white/5'
          }`}
        >
          Urefu
        </button>
        <button
          onClick={() => handleCategoryChange('weight')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 text-xs font-semibold rounded-lg transition-all ${
            category === 'weight'
              ? `${theme.equalsBtn.bg} text-white shadow-md`
              : 'text-slate-300 hover:text-white hover:bg-white/5'
          }`}
        >
          Uzito
        </button>
        <button
          onClick={() => handleCategoryChange('temperature')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 text-xs font-semibold rounded-lg transition-all ${
            category === 'temperature'
              ? `${theme.equalsBtn.bg} text-white shadow-md`
              : 'text-slate-300 hover:text-white hover:bg-white/5'
          }`}
        >
          Joto
        </button>
        <button
          onClick={() => handleCategoryChange('discount')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 text-xs font-semibold rounded-lg transition-all ${
            category === 'discount'
              ? `${theme.equalsBtn.bg} text-white shadow-md`
              : 'text-slate-300 hover:text-white hover:bg-white/5'
          }`}
        >
          Punguzo (%)
        </button>
      </div>

      {category !== 'discount' ? (
        /* Standard Unit Converter */
        <div className="space-y-4">
          {/* Input Box */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Kutoka (From)</span>
              <select
                value={fromUnitId}
                onChange={(e) => setFromUnitId(e.target.value)}
                className="bg-slate-900 text-white rounded-lg px-2.5 py-1 text-xs border border-white/20 focus:outline-none focus:ring-1 focus:ring-amber-400"
              >
                {getUnits().map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.nameSw} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>
            <input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="0"
              className="w-full bg-transparent text-3xl font-mono font-bold text-white focus:outline-none tracking-tight"
            />
          </div>

          {/* Swap Trigger */}
          <div className="flex justify-center -my-1">
            <button
              onClick={swapUnits}
              className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white border border-white/10 transition-all hover:scale-105 active:scale-95 shadow-md"
              title="Badili pande (Swap)"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
          </div>

          {/* Output Box */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 relative">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Kwenda (To)</span>
              <select
                value={toUnitId}
                onChange={(e) => setToUnitId(e.target.value)}
                className="bg-slate-900 text-white rounded-lg px-2.5 py-1 text-xs border border-white/20 focus:outline-none focus:ring-1 focus:ring-amber-400"
              >
                {getUnits().map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.nameSw} ({u.symbol})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-between">
              <span className={`text-3xl font-mono font-bold tracking-tight ${theme.accentColor}`}>
                {computeResult()}
              </span>
              <button
                onClick={() => handleCopy(computeResult())}
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                title="Nakili jibu"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Discount & Percentage Calculator */
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
              <label className="text-xs text-slate-400 block mb-1">Bei ya Awali</label>
              <input
                type="number"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                className="w-full bg-transparent text-xl font-mono font-bold text-white focus:outline-none"
              />
            </div>
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10">
              <label className="text-xs text-slate-400 block mb-1">Punguzo (%)</label>
              <input
                type="number"
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full bg-transparent text-xl font-mono font-bold text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Quick percentage chips */}
          <div className="flex items-center gap-1.5">
            {['5', '10', '15', '20', '25', '50'].map((pct) => (
              <button
                key={pct}
                onClick={() => setDiscountPercent(pct)}
                className={`flex-1 py-1 text-xs rounded-lg font-medium border transition-colors ${
                  discountPercent === pct
                    ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                }`}
              >
                {pct}%
              </button>
            ))}
          </div>

          {/* Calculation summary */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
            <div className="flex justify-between text-sm text-slate-300">
              <span>Kiasi cha Punguzo:</span>
              <span className="font-mono font-semibold text-rose-400">
                - {savedAmount.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between items-baseline pt-2 border-t border-white/10">
              <span className="text-sm font-semibold text-white">Bei ya Kulipa:</span>
              <span className={`text-2xl font-mono font-black ${theme.accentColor}`}>
                {finalPrice.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
