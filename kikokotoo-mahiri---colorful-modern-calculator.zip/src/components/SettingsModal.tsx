import React from 'react';
import { X, Volume2, Smartphone, Keyboard } from 'lucide-react';
import { SoundEffectType } from '../types/calculator';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  soundType: SoundEffectType;
  onSelectSound: (type: SoundEffectType) => void;
  hapticEnabled: boolean;
  onToggleHaptic: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  soundType,
  onSelectSound,
  hapticEnabled,
  onToggleHaptic,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl p-5 md:p-6 bg-slate-900 border border-white/10 shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              Mipangilio ya Kikokotoo
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Rekebisha sauti, mtikisiko na njia za mkato
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings list */}
        <div className="flex-1 overflow-y-auto py-4 space-y-5 custom-scrollbar">
          {/* Sound options */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-amber-400" />
              Mlio wa Vibonyezo (Key Sound)
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'soft', labelSw: 'Mpole (Soft)', labelEn: 'Sine Click' },
                { id: 'mechanical', labelSw: 'Mitambo (Key)', labelEn: 'Mechanical' },
                { id: 'bubble', labelSw: 'Mapovu (Pop)', labelEn: 'Water Pop' },
                { id: 'off', labelSw: 'Zima (Off)', labelEn: 'Silent' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectSound(item.id as SoundEffectType)}
                  className={`py-2 px-3 text-xs font-medium rounded-xl border text-left transition-all ${
                    soundType === item.id
                      ? 'bg-amber-400/20 border-amber-400 text-amber-300 font-bold'
                      : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <div>{item.labelSw}</div>
                  <div className="text-[10px] text-slate-400 opacity-70">{item.labelEn}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Haptic vibration toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">Mtikisiko (Haptic Feedback)</div>
                <div className="text-[11px] text-slate-400">Kwenye simu za mkononi</div>
              </div>
            </div>
            <button
              onClick={onToggleHaptic}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                hapticEnabled ? 'bg-amber-400' : 'bg-white/20'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-slate-950 transition-transform ${
                  hapticEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Keyboard cheatsheet */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
            <div className="text-xs font-semibold text-slate-300 flex items-center gap-2">
              <Keyboard className="w-4 h-4 text-cyan-400" />
              Njia za Mkato za Kibodi (Keyboard Shortcuts)
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
              <div className="flex items-center justify-between bg-black/30 px-2 py-1 rounded-lg">
                <span>0 - 9</span>
                <span className="font-mono text-slate-200">Namba</span>
              </div>
              <div className="flex items-center justify-between bg-black/30 px-2 py-1 rounded-lg">
                <span>+  -  *  /</span>
                <span className="font-mono text-slate-200">Alama</span>
              </div>
              <div className="flex items-center justify-between bg-black/30 px-2 py-1 rounded-lg">
                <span>Enter au =</span>
                <span className="font-mono text-slate-200">Jibu (=)</span>
              </div>
              <div className="flex items-center justify-between bg-black/30 px-2 py-1 rounded-lg">
                <span>Backspace</span>
                <span className="font-mono text-slate-200">Futa herufi</span>
              </div>
              <div className="flex items-center justify-between bg-black/30 px-2 py-1 rounded-lg">
                <span>Escape</span>
                <span className="font-mono text-slate-200">Futa yote (AC)</span>
              </div>
              <div className="flex items-center justify-between bg-black/30 px-2 py-1 rounded-lg">
                <span>%</span>
                <span className="font-mono text-slate-200">Asilimia</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            Funga
          </button>
        </div>
      </div>
    </div>
  );
};
