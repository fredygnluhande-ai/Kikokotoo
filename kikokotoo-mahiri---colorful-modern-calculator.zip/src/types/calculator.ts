export type CalculatorMode = 'standard' | 'scientific' | 'converter';

export type AngleMode = 'deg' | 'rad';

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: Date;
}

export type SoundEffectType = 'soft' | 'mechanical' | 'bubble' | 'off';

export interface ThemeColors {
  id: string;
  nameSw: string;
  nameEn: string;
  descriptionSw: string;
  previewGradient: string;
  pageBackground: string;
  calculatorBody: string;
  calculatorBorder: string;
  displayBackground: string;
  displayTextColor: string;
  displaySubTextColor: string;
  glowColor: string;
  numberBtn: {
    bg: string;
    text: string;
    hover: string;
    border: string;
  };
  functionBtn: {
    bg: string;
    text: string;
    hover: string;
    border: string;
  };
  operatorBtn: {
    bg: string;
    text: string;
    hover: string;
    active: string;
  };
  equalsBtn: {
    bg: string;
    text: string;
    hover: string;
    shadow: string;
  };
  accentColor: string;
  badgeBg: string;
}

export type UnitCategory = 'length' | 'weight' | 'temperature' | 'discount';
